package view;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Usuario
 */
public class JDlgProduto extends javax.swing.JDialog {

    public JDlgProduto(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setTitle("Cadastro do Produto");
        setLocationRelativeTo(null);
        desabilitar();

    }

    public void desabilitar() {
        jTxtCategoria.setEnabled(false);
        jTxtEstoque.setEnabled(false);
        jTxtNome.setEnabled(false);
        jTxtQuantidade.setEnabled(false);
        jTxtValor.setEnabled(false);
        jTxtIdProduto.setEnabled(false);

        jBtnConfirmar.setEnabled(false);
        jBtnCancelar.setEnabled(false);

        //os que vão habilitar
        jBtnExcluir.setEnabled(true);
        jBtnIncluir.setEnabled(true);
        jBtnPesquisar.setEnabled(true);
        jBtnAlterar.setEnabled(true);
    }

    public void habilitar() {
        jTxtCategoria.setEnabled(true);
        jTxtEstoque.setEnabled(true);
        jTxtNome.setEnabled(true);
        jTxtQuantidade.setEnabled(true);
        jTxtValor.setEnabled(true);
        jTxtIdProduto.setEnabled(true);

        jBtnConfirmar.setEnabled(true);
        jBtnCancelar.setEnabled(true);
        //os que vão desabilitar 
        jBtnExcluir.setEnabled(false);
        jBtnIncluir.setEnabled(false);
        jBtnPesquisar.setEnabled(false);
        jBtnAlterar.setEnabled(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTxtCategoria = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTxtNome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTxtEstoque = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTxtValor = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTxtQuantidade = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTxtIdProduto = new javax.swing.JTextField();
        panel1 = new java.awt.Panel();
        jBtnPesquisar = new javax.swing.JButton();
        jBtnConfirmar = new javax.swing.JButton();
        jBtnCancelar = new javax.swing.JButton();
        jBtnExcluir = new javax.swing.JButton();
        jBtnAlterar = new javax.swing.JButton();
        jBtnIncluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTxtCategoria.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCategoriaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCategoriaFocusLost(evt);
            }
        });
        getContentPane().add(jTxtCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 126, 166, -1));

        jLabel1.setText("Nome");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 20, -1, -1));

        jTxtNome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusLost(evt);
            }
        });
        getContentPane().add(jTxtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 63, 180, -1));

        jLabel2.setText("Estoque");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 101, -1, -1));

        jTxtEstoque.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEstoqueFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEstoqueFocusLost(evt);
            }
        });
        getContentPane().add(jTxtEstoque, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 126, 180, -1));

        jLabel3.setText("Valor");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 182, -1, -1));

        jTxtValor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtValorFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtValorFocusLost(evt);
            }
        });
        getContentPane().add(jTxtValor, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 214, 180, -1));

        jLabel4.setText("Quantidade");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 20, -1, -1));

        jTxtQuantidade.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtQuantidadeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtQuantidadeFocusLost(evt);
            }
        });
        getContentPane().add(jTxtQuantidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 63, 166, -1));

        jLabel5.setText("Categoria");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 101, -1, -1));

        jLabel6.setText("Código");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(286, 182, -1, -1));

        jTxtIdProduto.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtIdProdutoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtIdProdutoFocusLost(evt);
            }
        });
        getContentPane().add(jTxtIdProduto, new org.netbeans.lib.awtextra.AbsoluteConstraints(286, 214, 164, -1));

        panel1.setBackground(new java.awt.Color(51, 51, 51));

        jBtnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pesquisar.png"))); // NOI18N
        jBtnPesquisar.setText("Pesquisar");
        jBtnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPesquisarActionPerformed(evt);
            }
        });

        jBtnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/confirmar.png"))); // NOI18N
        jBtnConfirmar.setText("Confirmar");
        jBtnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnConfirmarActionPerformed(evt);
            }
        });

        jBtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cancelar.png"))); // NOI18N
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCancelarActionPerformed(evt);
            }
        });

        jBtnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Excluir.png"))); // NOI18N
        jBtnExcluir.setText("Excluir");
        jBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnExcluirActionPerformed(evt);
            }
        });

        jBtnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/alterar.png"))); // NOI18N
        jBtnAlterar.setText("Alterar");
        jBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAlterarActionPerformed(evt);
            }
        });

        jBtnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/incluir.png"))); // NOI18N
        jBtnIncluir.setText("Incluir");
        jBtnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnIncluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jBtnIncluir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBtnAlterar)
                .addGap(18, 18, 18)
                .addComponent(jBtnExcluir)
                .addGap(18, 18, 18)
                .addComponent(jBtnCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBtnConfirmar)
                .addGap(18, 18, 18)
                .addComponent(jBtnPesquisar))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtnPesquisar)
                    .addComponent(jBtnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBtnCancelar)
                    .addComponent(jBtnExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jBtnAlterar)
                    .addComponent(jBtnIncluir))
                .addContainerGap())
        );

        getContentPane().add(panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnIncluirActionPerformed
        // TODO add your handling code here:
        habilitar();
    }//GEN-LAST:event_jBtnIncluirActionPerformed

    private void jBtnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAlterarActionPerformed
        // TODO add your handling code here:
        habilitar();
    }//GEN-LAST:event_jBtnAlterarActionPerformed

    private void jBtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnExcluirActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jBtnExcluirActionPerformed

    private void jBtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCancelarActionPerformed
        // TODO add your handling code here:
        desabilitar();
    }//GEN-LAST:event_jBtnCancelarActionPerformed

    private void jBtnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnConfirmarActionPerformed
        // TODO add your handling code here:
        desabilitar();
    }//GEN-LAST:event_jBtnConfirmarActionPerformed

    private void jBtnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPesquisarActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jBtnPesquisarActionPerformed

    private void jTxtNomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusGained
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtNomeFocusGained

    private void jTxtNomeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusLost
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.white);
    }//GEN-LAST:event_jTxtNomeFocusLost

    private void jTxtEstoqueFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstoqueFocusGained
        // TODO add your handling code here:
        jTxtEstoque.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEstoqueFocusGained

    private void jTxtEstoqueFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstoqueFocusLost
        // TODO add your handling code here:
        jTxtEstoque.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEstoqueFocusLost

    private void jTxtValorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtValorFocusGained
        // TODO add your handling code here:
        jTxtValor.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtValorFocusGained

    private void jTxtValorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtValorFocusLost
        // TODO add your handling code here:
        jTxtValor.setBackground(Color.white);
    }//GEN-LAST:event_jTxtValorFocusLost

    private void jTxtQuantidadeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtQuantidadeFocusGained
        // TODO add your handling code here:
        jTxtQuantidade.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtQuantidadeFocusGained

    private void jTxtQuantidadeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtQuantidadeFocusLost
        // TODO add your handling code here:
        jTxtQuantidade.setBackground(Color.white);
    }//GEN-LAST:event_jTxtQuantidadeFocusLost

    private void jTxtCategoriaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCategoriaFocusGained
        // TODO add your handling code here:
        jTxtCategoria.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCategoriaFocusGained

    private void jTxtCategoriaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCategoriaFocusLost
        // TODO add your handling code here:
        jTxtCategoria.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCategoriaFocusLost

    private void jTxtIdProdutoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdProdutoFocusGained
        // TODO add your handling code here:
        jTxtIdProduto.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtIdProdutoFocusGained

    private void jTxtIdProdutoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdProdutoFocusLost
        // TODO add your handling code here:
        jTxtIdProduto.setBackground(Color.white);
    }//GEN-LAST:event_jTxtIdProdutoFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDlgProduto dialog = new JDlgProduto(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAlterar;
    private javax.swing.JButton jBtnCancelar;
    private javax.swing.JButton jBtnConfirmar;
    private javax.swing.JButton jBtnExcluir;
    private javax.swing.JButton jBtnIncluir;
    private javax.swing.JButton jBtnPesquisar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField jTxtCategoria;
    private javax.swing.JTextField jTxtEstoque;
    private javax.swing.JTextField jTxtIdProduto;
    private javax.swing.JTextField jTxtNome;
    private javax.swing.JTextField jTxtQuantidade;
    private javax.swing.JTextField jTxtValor;
    private java.awt.Panel panel1;
    // End of variables declaration//GEN-END:variables
}
