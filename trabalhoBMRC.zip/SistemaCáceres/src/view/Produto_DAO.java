package view;

import view.DAO_Abstract;

public class Produto_DAO extends DAO_Abstract {

    @Override //sobreescrita
    public void insert() {
        //implementarei depois
    }

    @Override
    public void update() {
        //implementarei depois
    }

    @Override
    public void delete() {
        //implementarei depois
    }
}
