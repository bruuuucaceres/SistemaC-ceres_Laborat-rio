package view;
//aula do dia: 28/02/2023.
//produto: cursos
//código
//nome do curso
//instructor
//data de início
//data de término
//confirmar e cancelar devem estar desativados ao incluir
//protect: um grupo de pessoas com permissão pode utilizar, 
//ele é só com herança, nível intermediário entre público e privado, 
//podem ser acessados por métodos da sub, super e pacote do sistema. 
//default: orelhão falso, através da herança pode acessar os atributos mesmo em outro pacote, 
//quando n é declarado o tipo de modificador de acesso, ele é o padrão
//o default faz com que o pacote esteja a nível do pacote
//exemplo de default (int: cnpj.) ele n tem declaração de público e nem privado.
//sobrecarga de métodos; dentro da mesma classe, métodos tenham nomes iguais.
//esta carcterística é chamada de sobrecarga (overload) de métodos
//sobrecarga: soma(int n1, n2, n3)
//quando se tem o nome de método mais os parámetros é chamados de assinatura de método
//n dá pra criar uma assinatura de método igual 
//mesmo nome de métodos mas com parâmetros dá pra compilar
//override n é o mesmo que overload
//override: acontece na herança, quando eu herdo posso refazer o método
//tipo, o método herda coisas mas posso refazer/mudar
//se tem sobrecarga de métodos tbm tem sobrecarga de construtor
//as subclasses herdam os atributos e métodos da superclasse, mas nã os seus construtores
//construtor: cria objetos, o contrutor em java é o nome da classe
//public Pessoa (){
//}
//public Pessoa (string nome){
//}
//psvm
//Pessoa pessoa = new Pessoa
//public Pessoa (String, int idade){ //sobrecarga de construtor
//}
//Pessoa pessoa = new Pessoa ("Bruna, 20");
//quando herda quais dos construtores vai ser herdado? o único contrutor que vai na herança é o padrão
//class carrEsportivo extends Carro{
//public void acelerar ()
//}
//Pacote é um conjunto de classes relacionadas.
//ideia de pacote: ter algo único
//bean, dao, img, view
//mvc Model (modelo) View (visão) e Controller (Controle), tela, banco de negócio e banco de dados em outro local
//minemonico: abreviação do que estou criando.
//ex: Jbtn, JFrm
//tudo em java é classe
//dois tipos de rotinas: procedimento e função em java: função sem retorno e com retorno.
//void: nulo, n retorna nada
//o set é void, o set altera
//o get pega e mostra
//esse método vai retornar alguma coisa? Se sim, deve - se colocar os tipos, se não é void.
//se o titulo está encapsulado deve ser colocado set title
//quando usa get e set é encapsulamento.
//alumas coisas tem atributos, outras são só métodos
//enable: true e false: 
//a vantagem de criar um método é vc consegue usar ele em outros lugares
// //desabilitado: confirmar e cancelar
// habilitado: o resto
//jFmtDataNascimento.setVisible(false); //para desabilitar o campo
//hola gente, que tal? Yo estoy haciendo pedidos de invitaciones personalisados para cumpleaños, trabajos por word, PowerPoint y Excel :)) Si se interesan estoy a disposición.
//alterar habilita
//incluir habilita
//confirmar desabilitar
//cancelar
////construtor, mesmo nome da classe
//evento: é uma ação que ocorre emcima da tela, quando clica no botão é um evento
//ideia do evento: dar uma resposta a algum objeto da tela
//evento dos focus: oobeto que está ativo no momento, é o campo que está pisacndo o cursor ou o botão que está circulado, um ganha foco e o outro perde
//quando o obejto ganha foco ele ganha um amarelinho, se não ele perde
//new cria u objeto de uma classe ; instanciar
// null: estará centralizado em relação a tela
//arrumar tela de vendas
//

public class Empresa {

    private String nome;
    private int cnpj;
    private double salario;  //real
    //boolean: true ou false

    //o construtor não é um método 
    public Empresa() { //construtor padão: construtor sem padrão.

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCnpj() {
        return cnpj;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public static void main(String[] args) {
        Empresa empresa = new Empresa();
        empresa.setNome("ifms");
        String cad = empresa.getNome();
    }
}
