package view;

import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

public class JDlgCliente extends javax.swing.JDialog {

    public JDlgCliente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        desabilitar();
        setTitle("Cadastro de Cliente");
        setLocationRelativeTo(null);
        desabilitar();
    }

    public void desabilitar() {
        jFmtDataNascimento.setEnabled(false);
        jTxtNome.setEnabled(false);
        jFmtCpf.setEnabled(false);
        jTxtTelefoneResidencial.setEnabled(false);
        jTxtSexo.setEnabled(false);
        jTxtRG.setEnabled(false);
        jTxtIdCliente.setEnabled(false);
        jTxtEstadoCivil.setEnabled(false);
        jTxtEndereco.setEnabled(false);
        jTxtEmail.setEnabled(false);
        jTxtCidade.setEnabled(false);
        jTxtCep.setEnabled(false);
        jTxtCelular.setEnabled(false);
        jTxtBairro.setEnabled(false);
        jChboAtivo.setEnabled(false);

        jBtnConfirmar.setEnabled(false);
        jBtnCancelar.setEnabled(false);

        //os que vão habilitar
        jBtnExcluir.setEnabled(true);
        jBtnIncluir.setEnabled(true);
        jBtnPesquisar.setEnabled(true);
        jBtnAlterar.setEnabled(true);

    }

    public void habilitar() {
        jFmtDataNascimento.setEnabled(true);
        jTxtNome.setEnabled(true);
        jFmtCpf.setEnabled(true);
        jTxtTelefoneResidencial.setEnabled(true);
        jTxtSexo.setEnabled(true);
        jTxtRG.setEnabled(true);
        jTxtIdCliente.setEnabled(true);
        jTxtEstadoCivil.setEnabled(true);
        jTxtEndereco.setEnabled(true);
        jTxtEmail.setEnabled(true);
        jTxtCidade.setEnabled(true);
        jTxtCep.setEnabled(true);
        jTxtCelular.setEnabled(true);
        jTxtBairro.setEnabled(true);
        jChboAtivo.setEnabled(true);

        jBtnConfirmar.setEnabled(true);
        jBtnCancelar.setEnabled(true);
        //os que vão desabilitar 
        jBtnExcluir.setEnabled(false);
        jBtnIncluir.setEnabled(false);
        jBtnPesquisar.setEnabled(false);
        jBtnAlterar.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTxtNome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTxtEmail = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTxtEstadoCivil = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTxtTelefoneResidencial = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTxtCidade = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTxtCelular = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jTxtBairro = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTxtSexo = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTxtIdCliente = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTxtEndereco = new javax.swing.JFormattedTextField();
        jLabel17 = new javax.swing.JLabel();
        jFmtDataNascimento = new javax.swing.JTextField();
        jTxtRG = new javax.swing.JTextField();
        jTxtCep = new javax.swing.JTextField();
        jChboAtivo = new javax.swing.JCheckBox();
        jPanel1 = new javax.swing.JPanel();
        jBtnIncluir = new javax.swing.JButton();
        jBtnExcluir = new javax.swing.JButton();
        jBtnCancelar = new javax.swing.JButton();
        jBtnAlterar = new javax.swing.JButton();
        jBtnConfirmar = new javax.swing.JButton();
        jBtnPesquisar = new javax.swing.JButton();
        jFmtCpf = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Tela de Cliente");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 11, -1, 23));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 278, -1, -1));

        jTxtNome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusLost(evt);
            }
        });
        getContentPane().add(jTxtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 134, 154, -1));

        jLabel3.setText("RG");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 114, -1, -1));

        jLabel4.setText("CPF");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 195, -1, -1));

        jLabel6.setText("E - mail");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 53, -1, -1));

        jTxtEmail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEmailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEmailFocusLost(evt);
            }
        });
        getContentPane().add(jTxtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 78, 185, -1));

        jLabel7.setText("CEP");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 116, -1, -1));

        jLabel8.setText("Estado Civil");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(206, 195, -1, -1));

        jTxtEstadoCivil.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEstadoCivilFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEstadoCivilFocusLost(evt);
            }
        });
        getContentPane().add(jTxtEstadoCivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(206, 220, 167, -1));

        jLabel9.setText("Telefone Residencial");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 258, -1, -1));

        jTxtTelefoneResidencial.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtTelefoneResidencialFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtTelefoneResidencialFocusLost(evt);
            }
        });
        getContentPane().add(jTxtTelefoneResidencial, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 279, 154, -1));

        jLabel10.setText("Cidade");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 48, -1, -1));

        jTxtCidade.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCidadeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCidadeFocusLost(evt);
            }
        });
        getContentPane().add(jTxtCidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 78, 183, -1));

        jLabel11.setText("Celular");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 191, -1, 23));

        jTxtCelular.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCelularFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCelularFocusLost(evt);
            }
        });
        getContentPane().add(jTxtCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 220, 183, -1));

        jLabel12.setText("Bairro");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(206, 258, -1, -1));

        jTxtBairro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtBairroFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtBairroFocusLost(evt);
            }
        });
        getContentPane().add(jTxtBairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(206, 279, 167, -1));

        jLabel13.setText("Sexo");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 56, -1, 16));

        jTxtSexo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtSexoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtSexoFocusLost(evt);
            }
        });
        getContentPane().add(jTxtSexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 78, 161, -1));

        jLabel14.setText("Código");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 45, -1, -1));

        jTxtIdCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtIdClienteFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtIdClienteFocusLost(evt);
            }
        });
        getContentPane().add(jTxtIdCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 76, 154, -1));

        jLabel15.setText("Nome");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 114, -1, -1));

        jLabel16.setText("Endereço");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 116, -1, -1));

        jTxtEndereco.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEnderecoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEnderecoFocusLost(evt);
            }
        });
        getContentPane().add(jTxtEndereco, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 141, 161, -1));

        jLabel17.setText("Data de Nascimento");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 258, -1, -1));

        jFmtDataNascimento.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFmtDataNascimentoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFmtDataNascimentoFocusLost(evt);
            }
        });
        getContentPane().add(jFmtDataNascimento, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 279, 183, -1));

        jTxtRG.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtRGFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtRGFocusLost(evt);
            }
        });
        getContentPane().add(jTxtRG, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 134, 185, -1));

        jTxtCep.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCepFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCepFocusLost(evt);
            }
        });
        getContentPane().add(jTxtCep, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 134, 183, -1));

        jChboAtivo.setText("Ativo");
        jChboAtivo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jChboAtivoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jChboAtivoFocusLost(evt);
            }
        });
        getContentPane().add(jChboAtivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(687, 278, -1, -1));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jBtnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/incluir.png"))); // NOI18N
        jBtnIncluir.setText("Incluir");
        jBtnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnIncluirActionPerformed(evt);
            }
        });

        jBtnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Excluir.png"))); // NOI18N
        jBtnExcluir.setText("Excluir");
        jBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnExcluirActionPerformed(evt);
            }
        });

        jBtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cancelar.png"))); // NOI18N
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCancelarActionPerformed(evt);
            }
        });

        jBtnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/alterar.png"))); // NOI18N
        jBtnAlterar.setText("Alterar");
        jBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAlterarActionPerformed(evt);
            }
        });

        jBtnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/confirmar.png"))); // NOI18N
        jBtnConfirmar.setText("Confirmar");
        jBtnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnConfirmarActionPerformed(evt);
            }
        });

        jBtnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pesquisar.png"))); // NOI18N
        jBtnPesquisar.setText("Pesquisar");
        jBtnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPesquisarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jBtnIncluir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBtnAlterar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBtnExcluir)
                .addGap(18, 18, 18)
                .addComponent(jBtnConfirmar)
                .addGap(18, 18, 18)
                .addComponent(jBtnCancelar)
                .addGap(18, 18, 18)
                .addComponent(jBtnPesquisar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtnIncluir)
                    .addComponent(jBtnExcluir)
                    .addComponent(jBtnCancelar)
                    .addComponent(jBtnAlterar)
                    .addComponent(jBtnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBtnPesquisar))
                .addGap(28, 28, 28))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(76, 329, -1, 58));

        jFmtCpf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusLost(evt);
            }
        });
        getContentPane().add(jFmtCpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 154, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPesquisarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnPesquisarActionPerformed

    private void jBtnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnConfirmarActionPerformed
        desabilitar();
    }//GEN-LAST:event_jBtnConfirmarActionPerformed

    private void jBtnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAlterarActionPerformed
        habilitar();
    }//GEN-LAST:event_jBtnAlterarActionPerformed

    private void jBtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCancelarActionPerformed

        desabilitar();
    }//GEN-LAST:event_jBtnCancelarActionPerformed

    private void jBtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnExcluirActionPerformed

    }//GEN-LAST:event_jBtnExcluirActionPerformed

    private void jBtnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnIncluirActionPerformed
        habilitar();
    }//GEN-LAST:event_jBtnIncluirActionPerformed

    private void jTxtIdClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdClienteFocusGained
        // TODO add your handling code here:
        jTxtIdCliente.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtIdClienteFocusGained

    private void jTxtIdClienteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdClienteFocusLost
        // TODO add your handling code here:
        jTxtIdCliente.setBackground(Color.white);
    }//GEN-LAST:event_jTxtIdClienteFocusLost

    private void jTxtNomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusGained
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtNomeFocusGained

    private void jTxtNomeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusLost
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.white);
    }//GEN-LAST:event_jTxtNomeFocusLost

    private void jFmtCpfFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusGained
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.pink);
    }//GEN-LAST:event_jFmtCpfFocusGained

    private void jFmtCpfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusLost
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.white);
    }//GEN-LAST:event_jFmtCpfFocusLost

    private void jTxtTelefoneResidencialFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtTelefoneResidencialFocusGained
        // TODO add your handling code here:
        jTxtTelefoneResidencial.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtTelefoneResidencialFocusGained

    private void jTxtTelefoneResidencialFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtTelefoneResidencialFocusLost
        // TODO add your handling code here:
        jTxtTelefoneResidencial.setBackground(Color.white);
    }//GEN-LAST:event_jTxtTelefoneResidencialFocusLost

    private void jTxtEmailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEmailFocusGained
        // TODO add your handling code here:
        jTxtEmail.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEmailFocusGained

    private void jTxtEmailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEmailFocusLost
        // TODO add your handling code here:
        jTxtEmail.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEmailFocusLost

    private void jTxtRGFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtRGFocusGained
        // TODO add your handling code here:
        jTxtRG.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtRGFocusGained

    private void jTxtRGFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtRGFocusLost
        // TODO add your handling code here:
        jTxtRG.setBackground(Color.white);
    }//GEN-LAST:event_jTxtRGFocusLost

    private void jTxtEstadoCivilFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstadoCivilFocusGained
        // TODO add your handling code here:
        jTxtEstadoCivil.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEstadoCivilFocusGained

    private void jTxtEstadoCivilFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstadoCivilFocusLost
        // TODO add your handling code here:
        jTxtEstadoCivil.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEstadoCivilFocusLost

    private void jTxtBairroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtBairroFocusLost
        // TODO add your handling code here:
        jTxtBairro.setBackground(Color.white);
    }//GEN-LAST:event_jTxtBairroFocusLost

    private void jTxtBairroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtBairroFocusGained
        // TODO add your handling code here:
        jTxtBairro.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtBairroFocusGained

    private void jTxtCidadeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCidadeFocusGained
        // TODO add your handling code here:
        jTxtCidade.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCidadeFocusGained

    private void jTxtCidadeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCidadeFocusLost
        // TODO add your handling code here:
        jTxtCidade.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCidadeFocusLost

    private void jTxtCepFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCepFocusGained
        // TODO add your handling code here:
        jTxtCep.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCepFocusGained

    private void jTxtCepFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCepFocusLost
        // TODO add your handling code here:
        jTxtCep.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCepFocusLost

    private void jTxtCelularFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCelularFocusGained
        // TODO add your handling code here:
        jTxtCelular.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCelularFocusGained

    private void jTxtCelularFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCelularFocusLost
        // TODO add your handling code here:
        jTxtCelular.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCelularFocusLost

    private void jFmtDataNascimentoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtDataNascimentoFocusGained
        // TODO add your handling code here:
        jFmtDataNascimento.setBackground(Color.pink);
    }//GEN-LAST:event_jFmtDataNascimentoFocusGained

    private void jFmtDataNascimentoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtDataNascimentoFocusLost
        // TODO add your handling code here:
        jFmtDataNascimento.setBackground(Color.white);
    }//GEN-LAST:event_jFmtDataNascimentoFocusLost

    private void jTxtSexoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtSexoFocusGained
        // TODO add your handling code here:
        jTxtSexo.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtSexoFocusGained

    private void jTxtSexoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtSexoFocusLost
        // TODO add your handling code here:
        jTxtSexo.setBackground(Color.white);
    }//GEN-LAST:event_jTxtSexoFocusLost

    private void jTxtEnderecoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEnderecoFocusGained
        // TODO add your handling code here:
        jTxtEndereco.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEnderecoFocusGained

    private void jTxtEnderecoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEnderecoFocusLost
        // TODO add your handling code here:
        jTxtEndereco.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEnderecoFocusLost

    private void jChboAtivoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jChboAtivoFocusGained
        // TODO add your handling code here:
        jChboAtivo.setBackground(Color.pink);
    }//GEN-LAST:event_jChboAtivoFocusGained

    private void jChboAtivoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jChboAtivoFocusLost
        // TODO add your handling code here:
        jChboAtivo.setBackground(Color.white);
    }//GEN-LAST:event_jChboAtivoFocusLost

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDlgCliente dialog = null;
                dialog = new JDlgCliente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAlterar;
    private javax.swing.JButton jBtnCancelar;
    private javax.swing.JButton jBtnConfirmar;
    private javax.swing.JButton jBtnExcluir;
    private javax.swing.JButton jBtnIncluir;
    private javax.swing.JButton jBtnPesquisar;
    private javax.swing.JCheckBox jChboAtivo;
    private javax.swing.JFormattedTextField jFmtCpf;
    private javax.swing.JTextField jFmtDataNascimento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTxtBairro;
    private javax.swing.JTextField jTxtCelular;
    private javax.swing.JTextField jTxtCep;
    private javax.swing.JTextField jTxtCidade;
    private javax.swing.JTextField jTxtEmail;
    private javax.swing.JFormattedTextField jTxtEndereco;
    private javax.swing.JTextField jTxtEstadoCivil;
    private javax.swing.JTextField jTxtIdCliente;
    private javax.swing.JTextField jTxtNome;
    private javax.swing.JTextField jTxtRG;
    private javax.swing.JTextField jTxtSexo;
    private javax.swing.JTextField jTxtTelefoneResidencial;
    // End of variables declaration//GEN-END:variables

}
