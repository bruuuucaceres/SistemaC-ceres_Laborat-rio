package view;

public abstract class DAO_Abstract {

    //classe abstrata é criada quando atribuimos o "abstract" depois do "public"
    public abstract void insert();  //metodo abstrato só é criado quando utilizamos o abstract

    public abstract void update(); // ctrl + shift + seta pra baixo = copia a linha   

    public abstract void delete();

    public void mensagem(String texto) {
        System.out.println(texto); //digitando sout + TAB = ele completa com a frase System.out.println()
        System.out.println("");
    }

}
